pip install pytest
pip install numpy
pip install pandas
sudo apt install python3-testresources
python -m pip install --upgrade pip
pip install --upgrade setuptools
pip install sklearn
pip install azureml-sdk
pip install azureml-core