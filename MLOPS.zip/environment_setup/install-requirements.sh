python --version
#pip install --upgrade azure-cli
pip install azure-cli==2.30.0
pip install --upgrade azureml-sdk[cli]
pip install pytest
pip install pytest-cov
#pip install -r requirements.txt

pip install joblib

pip install azureml-monitoring

pip install sklearn

pip install azureml-core
#pip install -r requirements.txt

 pip install azureml-datadrift
