def drift_func(baseline_dataset_name,root_path,trained_filepath,test_filepath,backfill_start_date,backfill_end_date,cluster_name,date_column):
   
    from azureml.core import Workspace
    ws = Workspace(subscription_id = 'd6014779-aa16-43ea-b550-715da415ecdc', resource_group = 
    'rg-TestML-dev',workspace_name = 'mlworkspace')
    ws.write_config()
    import pandas as pd
    from azureml.core import Datastore, Dataset
    import datetime as dt
    from azureml.core.compute import ComputeTarget, AmlCompute
    from azureml.datadrift import DataDriftDetector
    from azureml.core.compute_target import ComputeTargetException
    default_ds = ws.get_default_datastore()
    default_ds.upload_files(files=[trained_filepath,test_filepath],
                       target_path= root_path,
                       overwrite=True,
                       show_progress=True)
    baseline_data_set = Dataset.Tabular.from_delimited_files(path=(default_ds, root_path))
    baseline_data_set = baseline_data_set.register(workspace=ws,
                           name= baseline_dataset_name,                        
                           tags = {'format':'CSV'},
                           create_new_version=True)
    cluster_name = "none"

    try:
        # Check for existing compute target
        training_cluster = ComputeTarget(workspace=ws, name=cluster_name)
        print('Found existing cluster, use it.')
    except ComputeTargetException:
        # If it doesn't already exist, create it
        try:
            compute_config = AmlCompute.provisioning_configuration(vm_size='STANDARD_DS11_V2', max_nodes=2)
            training_cluster = ComputeTarget.create(ws, cluster_name, compute_config)
            training_cluster.wait_for_completion(show_output=True)
        except Exception as ex:
            print(ex)
    data = pd.read_csv(test_filepath)
    data[date_column] = pd.to_datetime(data[date_column])

    target = Dataset.Tabular.from_delimited_files(default_ds.path(root_path))
    target = target.with_timestamp_columns('datetime')
    target = target.register(ws,'target')
    target = Dataset.get_by_name(ws,'target')
    features = data.columns.to_list()
    monitor = DataDriftDetector.create_from_datasets(ws, 'monitor1', baseline_data_set, target,
                                                      compute_target=cluster_name, 
                                                      frequency='Month', 
                                                      feature_list=features, 
                                                      drift_threshold=.3, 
                                                      latency=24)
    backfill_start_date = pd.to_datetime(backfill_start_date,format='%Y%m%d')
    backfill_end_date = pd.to_datetime(backfill_end_date,format='%Y%m%d')
    backfill = monitor.backfill(backfill_start_date,backfill_end_date)
    backfill.wait_for_completion(wait_post_processing=True)
    drift_metrics = backfill.get_metrics()

    
    print(drift_metrics)
drift_func('iris_baseline',
            'iris-baseline/*.csv',
            './data/Iris.csv',
            './data/Iris_target.csv',
            20120301,
            20120529,
            'mlcompute',
            'datetime')