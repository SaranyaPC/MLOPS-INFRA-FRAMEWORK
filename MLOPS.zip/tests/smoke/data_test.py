# test integrity of the input data
import os
import numpy as np
import pandas as pd
import pytest

# get absolute path of csv files from data folder
def get_absPath(filename):
    """Returns the path of the notebooks folder"""
    path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), os.path.pardir, os.path.pardir, "data", filename
        )
    )
    return path

# number of features
expected_columns = 4
expected_columns2 = 10

# distribution of features in the training set
historical_mean = np.array(
    [
        -3.63962254e-16,
        1.26972339e-16,
        -8.01646331e-16,
        1.28856202e-16,
        -8.99230414e-17,
        1.29609747e-16,
        -4.56397112e-16,
        3.87573332e-16,
        -3.84559152e-16,
        -3.39848813e-16,
        1.52133484e02,
    ]
)
historical_std = np.array(
    [
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        4.75651494e-02,
        7.70057459e01,
    ]
)

# maximal relative change in feature mean or standrd deviation
# that we can tolerate
shift_tolerance = 3


def test_check_schema():
    datafile = get_absPath("/home/vsts/work/r1/a/_MLOPS-CI/ml_artifacts/s/data/Iris1.csv")
    # check that file exists
    assert os.path.exists(datafile)
    dataset = pd.read_csv(datafile)
    header = dataset[dataset.columns[:-1]]
    actual_columns = header.shape[1]
    # check header has expected number of columns
    assert actual_columns == expected_columns


def test_check_bad_schema():
    datafile = get_absPath("/home/vsts/work/r1/a/_MLOPS-CI/ml_artifacts/s/data/Iris1.csv")
    # check that file exists
    assert os.path.exists(datafile)
    dataset = pd.read_csv(datafile)
    header = dataset[dataset.columns[:-1]]
    actual_columns = header.shape[1]
    # check header has expected number of columns
    assert actual_columns != expected_columns2


def test_check_missing_values():
    datafile = get_absPath("/home/vsts/work/r1/a/_MLOPS-CI/ml_artifacts/s/data/Iris1.csv")
    # check that file exists
    assert os.path.exists(datafile)
    dataset = pd.read_csv(datafile)
    n_nan = np.sum(np.isnan(dataset.values))
    assert n_nan >= 0

